#ifndef SHELL_H
#define SHELL_H

#include <stdint.h>

void startShell();

#endif