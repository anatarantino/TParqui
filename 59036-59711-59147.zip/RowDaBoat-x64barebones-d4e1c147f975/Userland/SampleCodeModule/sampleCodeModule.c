#include <shell.h>
#include <prints.h>
int main() {
	startShell();
	return 0;
}