#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <stdint.h>

uint8_t get_key();
uint8_t pressed_key();

#endif