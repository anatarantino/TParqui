#ifndef COLORS_H
#define COLORS_H

#define WHITE 0xFFFFFF
#define BLACK 0x000000
#define RED 0xFF0000
#define GREEN 0X00FF00
#define VIOLET 0x7F00FF
#define YELLOW 0xFFFF00

#endif