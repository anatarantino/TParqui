#ifndef IDTFILE_H
#define IDTFILE_H

void load_idt();

#endif